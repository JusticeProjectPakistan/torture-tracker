module.exports.regions = [{
    "name": "Northern Areas~Northern Areas"
  },
  {
    "name": "Azad Kashmir~Azad Kashmir"
  },
  {
    "name": "Khyber Pakhtunkhawa~Abbottabad"
  },
  {
    "name": "Khyber Pakhtunkhawa~Bajur"
  },
  {
    "name": "Khyber Pakhtunkhawa~Bannu"
  },
  {
    "name": "Khyber Pakhtunkhawa~Batagram"
  },
  {
    "name": "Khyber Pakhtunkhawa~Bunair"
  },
  {
    "name": "Khyber Pakhtunkhawa~Charsada"
  },
  {
    "name": "Khyber Pakhtunkhawa~Chitral"
  },
  {
    "name": "Khyber Pakhtunkhawa~D. I. Khan"
  },
  {
    "name": "Khyber Pakhtunkhawa~Hangu"
  },
  {
    "name": "Khyber Pakhtunkhawa~Haripur"
  },
  {
    "name": "Khyber Pakhtunkhawa~Karak"
  },
  {
    "name": "Khyber Pakhtunkhawa~Khyber"
  },
  {
    "name": "Khyber Pakhtunkhawa~Kohat"
  },
  {
    "name": "Khyber Pakhtunkhawa~Kohistan"
  },
  {
    "name": "Khyber Pakhtunkhawa~Kurram"
  },
  {
    "name": "Khyber Pakhtunkhawa~Lakki Marwat"
  },
  {
    "name": "Khyber Pakhtunkhawa~Lower Dir"
  },
  {
    "name": "Khyber Pakhtunkhawa~Malakand"
  },
  {
    "name": "Khyber Pakhtunkhawa~Mansehra"
  },
  {
    "name": "Khyber Pakhtunkhawa~Mardan"
  },
  {
    "name": "Khyber Pakhtunkhawa~Mohmand"
  },
  {
    "name": "Khyber Pakhtunkhawa~North Waziristan"
  },
  {
    "name": "Khyber Pakhtunkhawa~Nowshera"
  },
  {
    "name": "Khyber Pakhtunkhawa~Orakzai"
  },
  {
    "name": "Khyber Pakhtunkhawa~Peshawar"
  },
  {
    "name": "Khyber Pakhtunkhawa~Shangla"
  },
  {
    "name": "Khyber Pakhtunkhawa~South Waziristan"
  },
  {
    "name": "Khyber Pakhtunkhawa~Swabi"
  },
  {
    "name": "Khyber Pakhtunkhawa~Swat"
  },
  {
    "name": "Khyber Pakhtunkhawa~Tank"
  },
  {
    "name": "Khyber Pakhtunkhawa~Tor Garh"
  },
  {
    "name": "Khyber Pakhtunkhawa~Upper Dir"
  },
  {
    "name": "Punjab~Attock"
  },
  {
    "name": "Punjab~Bahawalnagar"
  },
  {
    "name": "Punjab~Bahawalpur"
  },
  {
    "name": "Punjab~Bhakhar"
  },
  {
    "name": "Punjab~Chakwal"
  },
  {
    "name": "Punjab~Chiniot"
  },
  {
    "name": "Punjab~D. G. Khan"
  },
  {
    "name": "Punjab~Faisalabad"
  },
  {
    "name": "Punjab~Gujranwala"
  },
  {
    "name": "Punjab~Gujrat"
  },
  {
    "name": "Punjab~Hafizabad"
  },
  {
    "name": "Punjab~Islamabad"
  },
  {
    "name": "Punjab~Jehlum"
  },
  {
    "name": "Punjab~Jhang"
  },
  {
    "name": "Punjab~Kasur"
  },
  {
    "name": "Punjab~Khanewal"
  },
  {
    "name": "Punjab~Khushab"
  },
  {
    "name": "Punjab~Lahore"
  },
  {
    "name": "Punjab~Layyah"
  },
  {
    "name": "Punjab~Lodhran"
  },
  {
    "name": "Punjab~Mandi Bahauddin"
  },
  {
    "name": "Punjab~Mianwali"
  },
  {
    "name": "Punjab~Multan"
  },
  {
    "name": "Punjab~Muzaffar Garh"
  },
  {
    "name": "Punjab~Nankana Sahib"
  },
  {
    "name": "Punjab~Narowal 226"
  },
  {
    "name": "Punjab~Okara"
  },
  {
    "name": "Punjab~Pakpattan"
  },
  {
    "name": "Punjab~Rahim Yar Khan"
  },
  {
    "name": "Punjab~Rajanpur"
  },
  {
    "name": "Punjab~Rawalpindi"
  },
  {
    "name": "Punjab~Sahiwal"
  },
  {
    "name": "Punjab~Sargodha"
  },
  {
    "name": "Punjab~Sheikhupura"
  },
  {
    "name": "Punjab~Sialkot"
  },
  {
    "name": "Punjab~T.T. Singh"
  },
  {
    "name": "Punjab~Vehari"
  },
  {
    "name": "Sindh~Badin"
  },
  {
    "name": "Sindh~Dadu"
  },
  {
    "name": "Sindh~Ghotki"
  },
  {
    "name": "Sindh~Hyderabad"
  },
  {
    "name": "Sindh~Jacobabad"
  },
  {
    "name": "Sindh~Jamshoro"
  },
  {
    "name": "Sindh~Karachi Central"
  },
  {
    "name": "Sindh~Karachi East"
  },
  {
    "name": "Sindh~Karachi Malir"
  },
  {
    "name": "Sindh~Karachi South"
  },
  {
    "name": "Sindh~Karachi West"
  },
  {
    "name": "Sindh~Kashmore"
  },
  {
    "name": "Sindh~Khairpur"
  },
  {
    "name": "Sindh~Korangi"
  },
  {
    "name": "Sindh~Larkana"
  },
  {
    "name": "Sindh~Matiari"
  },
  {
    "name": "Sindh~Mir Pur Khas"
  },
  {
    "name": "Sindh~Nowshero Feroze"
  },
  {
    "name": "Sindh~Sanghar"
  },
  {
    "name": "Sindh~Shahdadkot"
  },
  {
    "name": "Sindh~Shaheed Banazir Abad"
  },
  {
    "name": "Sindh~Shikarpur"
  },
  {
    "name": "Sindh~Sujawal"
  },
  {
    "name": "Sindh~Sukkur"
  },
  {
    "name": "Sindh~Tando Allah Yar"
  },
  {
    "name": "Sindh~Tando Muhammad Khan"
  },
  {
    "name": "Sindh~Tharparkar"
  },
  {
    "name": "Sindh~Thatta"
  },
  {
    "name": "Sindh~Umer Kot"
  },
  {
    "name": "Balochistan~Awaran"
  },
  {
    "name": "Balochistan~Barkhan"
  },
  {
    "name": "Balochistan~Chagai"
  },
  {
    "name": "Balochistan~Dera Bugti"
  },
  {
    "name": "Balochistan~Duki"
  },
  {
    "name": "Balochistan~Gwadar"
  },
  {
    "name": "Balochistan~Harnai"
  },
  {
    "name": "Balochistan~Jaffarabad"
  },
  {
    "name": "Balochistan~Jhal Magsi"
  },
  {
    "name": "Balochistan~Kachhi/Bolan"
  },
  {
    "name": "Balochistan~Kalat"
  },
  {
    "name": "Balochistan~Kech/Turbat"
  },
  {
    "name": "Balochistan~Kharan"
  },
  {
    "name": "Balochistan~Khuzdar"
  },
  {
    "name": "Balochistan~Kohlu"
  },
  {
    "name": "Balochistan~Lasbela"
  },
  {
    "name": "Balochistan~Loralai"
  },
  {
    "name": "Balochistan~Mastung"
  },
  {
    "name": "Balochistan~Musa Khel"
  },
  {
    "name": "Balochistan~Nasirabad/Tamboo"
  },
  {
    "name": "Balochistan~Nushki"
  },
  {
    "name": "Balochistan~Panjgoor"
  },
  {
    "name": "Balochistan~Pishin"
  },
  {
    "name": "Balochistan~Qilla Abdullah"
  },
  {
    "name": "Balochistan~Qilla Saifullah"
  },
  {
    "name": "Balochistan~Quetta"
  },
  {
    "name": "Balochistan~Shaheed Sikandar Abad"
  },
  {
    "name": "Balochistan~Sherani"
  },
  {
    "name": "Balochistan~Sibbi"
  },
  {
    "name": "Balochistan~Sohbatpur"
  },
  {
    "name": "Balochistan~Washuk"
  },
  {
    "name": "Balochistan~Zhob"
  },
  {
    "name": "Balochistan~Ziarat"
  }
];